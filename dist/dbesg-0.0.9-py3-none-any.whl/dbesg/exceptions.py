class OrderError(ValueError):
    pass

class CompoundedError(ValueError):
    pass