import unittest

class DBESGTestCase001(unittest.TestCase):

    def setUp(self):
        """ 테스트 시작 전 """
        pass

    def tearDown(self):
        """ 테스트 종료 후 """
        print("테스트를 종료합니다.")

    def test_runs(self):
        pass